import React, { useState } from 'react';
import './DropDown.css';

const DropDown = () => {
  const [showMenu1, setShowMenu1] = useState(false);
  const [showMenu2, setShowMenu2] = useState(false);
  const [iconState1, setIconState1] = useState('plus');
  const [iconState2, setIconState2] = useState('plus');

  const toggleMenu1 = () => {
    setShowMenu1(!showMenu1);
    setIconState1(iconState1 === 'plus' ? 'minus' : 'plus');
  };

  const toggleMenu2 = () => {
    setShowMenu2(!showMenu2);
    setIconState2(iconState2 === 'plus' ? 'minus' : 'plus');
  };

  return (
    <div className='container'>
      <div className='row'>
        <div className='col-lg-12'>
          <div className='sidebarmenu'>
            <ul className='sidebarmenu-sub'>
              <li className='menu-item'>Home</li>
              <button onClick={toggleMenu1}>
                {iconState1 === 'plus' ? (
                  <i className='fa-solid fa-plus'></i>
                ) : (
                  <i className='fa-solid fa-minus'></i>
                )}
              </button>
            </ul>
            <ul className={showMenu1 ? 'sub-menu slide-down' : 'sub-menu'}>
              <li className='submenu-item'>Submenu 1 </li>
              <li className='submenu-item'>Submenu 2</li>
              <li className='submenu-item'>Submenu 3</li>
              <li className='submenu-item'>Submenu 4</li>
            </ul>
            <ul className='sidebarmenu-sub'>
              <li className='menu-item'>About</li>
              <button onClick={toggleMenu2}>
                {iconState2 === 'plus' ? (
                  <i className='fa-solid fa-plus'></i>
                ) : (
                  <i className='fa-solid fa-minus'></i>
                )}
              </button>
            </ul>
            <ul className={showMenu2 ? 'sub-menu slide-down' : 'sub-menu'}>
              <li className='submenu-item'>Submenu 1</li>
              <li className='submenu-item'>Submenu 2</li>
              <li className='submenu-item'>Submenu 3</li>
              <li className='submenu-item'>Submenu 4</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DropDown;
