import React from 'react'
import Banner from './Banner/Banner'

import Navbar from './Navbar/Navbar'
import ProductOffer from './ProductsOffer/ProductsOffer'
import ProductGroup from './ProductsGroup/ProductsGroup'
import Footer from './Footer/Footer'
import MoreProducts from './MoreProducts/MoreProducts'

const Home = () => {
  return (
    <>
      <Navbar />
      <Banner />
      <MoreProducts />
      <ProductGroup />
      <ProductOffer />
      <ProductGroup />
      <ProductOffer />
      <ProductGroup />

      <Footer />
    </>
  )
}

export default Home
