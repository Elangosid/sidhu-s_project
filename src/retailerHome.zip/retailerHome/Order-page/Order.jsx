import React, { useState } from 'react'
import Navbar from '../Navbar/Navbar'
import ProductImg from '../Assets/Rice.png'
import ProductImg1 from '../Assets/Oil.png'
import Footer from '../Footer/Footer'
import productBadge from '../../assets/BB-images/Retailer/product-badge.png'
import './Order.css'
import { Container, Card, Col, Row, Button } from 'react-bootstrap'

const Order = () => {
  const [activeContainer, setActiveContainer] = useState('container-1')

  return (
    <div>
      <Navbar />
      <div className='container'>
        <h2 className='mt-3'>Order Details</h2>
        <div
          style={{ backgroundColor: '#EFF4EA', border: 'solid #EFF4EA' }}
          className='btns row d-flex align-item-center justify-content-center text-white p-2'
        >
          <div className='col-4 text-center'>
            <button
              id='btns'
              className='btn border btn-success'
              onClick={() => setActiveContainer('container-1')}
            >
              Summary
            </button>
          </div>
          <div className='col-3 text-center'>
            <button
              id='btns'
              className='btn border btn-success'
              onClick={() => setActiveContainer('container-2')}
            >
              Items
            </button>
          </div>
          <div className='col-3 text-center'>
            <button
              id='btns'
              className='btn border btn-success'
              onClick={() => setActiveContainer('container-3')}
            >
              Track
            </button>
          </div>
        </div>

        {activeContainer === 'container-1' && (
          <div className='container-1 mt-3'>
            <div style={{ backgroundColor: '#FFFFFF' }} className='row '>
              <div className='d-flex'>
                <h3>Products</h3>
                <p className='mt-2 ms-2 text-muted'>(Total 11)</p>
              </div>
              <div className='product col'>
                <img src={ProductImg} alt='none' srcset='' width={150} />
              </div>
              <div className='product col'>
                <img src={ProductImg1} alt='none' srcset='' width={150} />
              </div>
              <div className='product col'>
                <img src={ProductImg1} alt='none' srcset='' width={150} />
              </div>
              <div className='product col'>
                <img src={ProductImg} alt='none' srcset='' width={150} />
              </div>
              <div className='product col'>
                <img src={ProductImg1} alt='none' srcset='' width={150} />
              </div>
              <div className='product col'>
                <button className='btn-success btn btn-1 mt-5'>
                  <span>5+</span>
                  <br />
                  <span>See all</span>
                </button>
              </div>
            </div>

            <div className='price-details mt-2 row '>
              <div className=' '>
                <div style={{ backgroundColor: '#55951A0A' }} className='row'>
                  <h4 className='fw-bold'>Price Deatails</h4>
                  <div className='col col-lg-3  mt-3'>
                    <div className='d-flex'>
                      <p>Item Total amount</p>
                      <i class='bi bi-chevron-down ms-2'></i>
                    </div>
                    <div className='d-flex'>
                      <p>Taxes & Delivery Charges</p>
                      <i class='bi bi-chevron-down ms-2'></i>
                    </div>
                    <div className='d-flex'>
                      <p>Discount/Offer</p>
                      <i class='bi bi-percent text-success ms-1'></i>
                    </div>
                    <div className='d-flex'>
                      <p>Margin</p>
                      <i class='bi bi-chevron-down ms-2'></i>
                    </div>
                    <div className='d-flex'>
                      <p>Grand Total</p>
                    </div>
                  </div>

                  <div className='col  col-lg-4    mt-3'>
                    <div className='d-flex'>
                      <p>₹ 25098.00</p>
                    </div>
                    <div className='d-flex'>
                      <p>₹ 250.00</p>
                    </div>
                    <div className='d-flex'>
                      <p className='text-success'>(-)₹599.00</p>
                    </div>
                    <div className='d-flex'>
                      <p>₹ 250.00</p>
                    </div>
                    <div className='d-flex'>
                      <p>₹ 25098.00</p>
                    </div>
                  </div>
                  <div className=' col-lg-5 col-sm-12 col-xs-12'>
                    <h2>Delivery</h2>
                    <p>
                      <span>
                        <i class='bi bi-geo-alt-fill text-success me-1'></i>
                      </span>
                      101-209-21, Cubbon ParkNearest Metro Station, Bus Stand
                      Road, Dr. B.R. Ambedkar Station ...
                    </p>
                    <p>Vidhana Soudha , Bangalore - 560087</p>
                    <p>
                      <span>
                        <i class='bi bi-telephone-fill text-success me-1'></i>
                      </span>
                      +91-9873645345
                    </p>
                    <button className='btns'>
                      <span>
                        <i class='bi bi-file-earmark-medical me-1'></i>
                      </span>
                      Download Invoice
                    </button>
                  </div>
                  <div className=''>
                    <span
                      className='p-1'
                      style={{
                        color: '#FF7043 ',
                        border: 'dotted #FD916D',
                        backgroundColor: '#fd916d3b',
                      }}
                    >
                      You have saved ₹599 on this order
                    </span>
                  </div>

                  <div className='col mt-3'>
                    {' '}
                    <span
                      style={{
                        backgroundColor: '#8c8c8c3e',
                        border: 'dotted #8c8c8c6e',
                      }}
                      className='p-1 '
                    >
                      <i class='bi bi-truck text-success border-2 border me-2'></i>
                      Cash on Delivery (COD){' '}
                      <span style={{ backgroundColor: '' }}>
                        <a
                          style={{ color: '#45bc1b' }}
                          className=' ms-2'
                          href='#'
                        >
                          Free
                        </a>
                      </span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeContainer === 'container-2' && (
          <div className='container-2'>
            <section className='productsgroup'>
              <div className='container-fluid container-productsgroup'>
                <div className='d-flex'>
                  <h3>Products</h3>
                  <p className='mt-2 ms-2 text-muted'>(Total 11)</p>
                </div>
                <div className='row'>
                  <div className='col productsgroup-all mb-3'>
                    <div className='sinngleproduct'>
                      <div className='product-img'>
                        <img
                          src={ProductImg}
                          alt='...'
                          className='single-img'
                          width={50}
                          height={50}
                        />
                      </div>
                      <div className='product-badge'>
                        <div className='badge-text'>
                          <img
                            src={productBadge}
                            alt='...'
                            className='badge-img'
                          />
                          <div className='badge-des'>Margin -45.9</div>
                        </div>
                      </div>
                      <div className='product-detail'>
                        <h5>Fresh Malabar Parota</h5>
                        <p>Qty-2Kg (10 Pockets)</p>
                        <p className='text-dark'> &#x20B9; 199</p>
                      </div>
                    </div>
                  </div>
                  <div className='col productsgroup-all mb-3'>
                    <div className='sinngleproduct'>
                      <div className='product-img'>
                        <img
                          src={ProductImg}
                          alt='...'
                          className='single-img'
                          width={50}
                          height={50}
                        />
                      </div>
                      <div className='product-badge'>
                        <div className='badge-text'>
                          <img
                            src={productBadge}
                            alt='...'
                            className='badge-img'
                          />
                          <div className='badge-des'>Margin -45.9</div>
                        </div>
                      </div>
                      <div className='product-detail'>
                        <h5>Fresh Malabar Parota</h5>
                        <p>Qty-2Kg (10 Pockets)</p>
                        <p className='text-dark'> &#x20B9; 199</p>
                      </div>
                    </div>
                  </div>
                  <div className='col productsgroup-all mb-3'>
                    <div className='sinngleproduct'>
                      <div className='product-img'>
                        <img
                          src={ProductImg}
                          alt='...'
                          className='single-img'
                          width={50}
                          height={50}
                        />
                      </div>
                      <div className='product-badge'>
                        <div className='badge-text'>
                          <img
                            src={productBadge}
                            alt='...'
                            className='badge-img'
                          />
                          <div className='badge-des'>Margin -45.9</div>
                        </div>
                      </div>
                      <div className='product-detail'>
                        <h5>Fresh Malabar Parota</h5>
                        <p>Qty-2Kg (10 Pockets)</p>
                        <p className='text-dark'> &#x20B9; 199</p>
                      </div>
                    </div>
                  </div>
                  <div className='col productsgroup-all mb-3'>
                    <div className='sinngleproduct'>
                      <div className='product-img'>
                        <img
                          src={ProductImg}
                          alt='...'
                          className='single-img'
                          width={50}
                          height={50}
                        />
                      </div>
                      <div className='product-badge'>
                        <div className='badge-text'>
                          <img
                            src={productBadge}
                            alt='...'
                            className='badge-img'
                          />
                          <div className='badge-des'>Margin -45.9</div>
                        </div>
                      </div>
                      <div className='product-detail'>
                        <h5>Fresh Malabar Parota</h5>
                        <p>Qty-2Kg (10 Pockets)</p>
                        <p className='text-dark'> &#x20B9; 199</p>
                      </div>
                    </div>
                  </div>
                  <div className='col productsgroup-all mb-3'>
                    <div className='sinngleproduct'>
                      <div className='product-img'>
                        <img
                          src={ProductImg}
                          alt='...'
                          className='single-img'
                          width={50}
                          height={50}
                        />
                      </div>
                      <div className='product-badge'>
                        <div className='badge-text'>
                          <img
                            src={productBadge}
                            alt='...'
                            className='badge-img'
                          />
                          <div className='badge-des'>Margin -45.9</div>
                        </div>
                      </div>
                      <div className='product-detail'>
                        <h5>Fresh Malabar Parota</h5>
                        <p>Qty-2Kg (10 Pockets)</p>
                        <p className='text-dark'> &#x20B9; 199</p>
                      </div>
                    </div>
                  </div>
                  <div className='col productsgroup-all mb-3'>
                    <div className='sinngleproduct'>
                      <div className='product-img'>
                        <img
                          src={ProductImg}
                          alt='...'
                          className='single-img'
                          width={50}
                          height={50}
                        />
                      </div>
                      <div className='product-badge'>
                        <div className='badge-text'>
                          <img
                            src={productBadge}
                            alt='...'
                            className='badge-img'
                          />
                          <div className='badge-des'>Margin -45.9</div>
                        </div>
                      </div>
                      <div className='product-detail'>
                        <h5>Fresh Malabar Parota</h5>
                        <p>Qty-2Kg (10 Pockets)</p>
                        <p className='text-dark'> &#x20B9; 199</p>
                      </div>
                    </div>
                  </div>
                  <div className='col productsgroup-all mb-3'>
                    <div className='sinngleproduct'>
                      <div className='product-img'>
                        <img
                          src={ProductImg}
                          alt='...'
                          className='single-img'
                          width={50}
                          height={50}
                        />
                      </div>
                      <div className='product-badge'>
                        <div className='badge-text'>
                          <img
                            src={productBadge}
                            alt='...'
                            className='badge-img'
                          />
                          <div className='badge-des'>Margin -45.9</div>
                        </div>
                      </div>
                      <div className='product-detail'>
                        <h5>Fresh Malabar Parota</h5>
                        <p>Qty-2Kg (10 Pockets)</p>
                        <p className='text-dark'> &#x20B9; 199</p>
                      </div>
                    </div>
                  </div>
                  <div className='col productsgroup-all mb-3'>
                    <div className='sinngleproduct'>
                      <div className='product-img'>
                        <img
                          src={ProductImg}
                          alt='...'
                          className='single-img'
                          width={50}
                          height={50}
                        />
                      </div>
                      <div className='product-badge'>
                        <div className='badge-text'>
                          <img
                            src={productBadge}
                            alt='...'
                            className='badge-img'
                          />
                          <div className='badge-des'>Margin -45.9</div>
                        </div>
                      </div>
                      <div className='product-detail'>
                        <h5>Fresh Malabar Parota</h5>
                        <p>Qty-2Kg (10 Pockets)</p>
                        <p className='text-dark'> &#x20B9; 199</p>
                      </div>
                    </div>
                  </div>
                  <div className='col productsgroup-all mb-3'>
                    <div className='sinngleproduct'>
                      <div className='product-img'>
                        <img
                          src={ProductImg}
                          alt='...'
                          className='single-img'
                          width={50}
                          height={50}
                        />
                      </div>
                      <div className='product-badge'>
                        <div className='badge-text'>
                          <img
                            src={productBadge}
                            alt='...'
                            className='badge-img'
                          />
                          <div className='badge-des'>Margin -45.9</div>
                        </div>
                      </div>
                      <div className='product-detail'>
                        <h5>Fresh Malabar Parota</h5>
                        <p>Qty-2Kg (10 Pockets)</p>
                        <p className='text-dark'> &#x20B9; 199</p>
                      </div>
                    </div>
                  </div>
                  <div className='col productsgroup-all mb-3'>
                    <div className='sinngleproduct'>
                      <div className='product-img'>
                        <img
                          src={ProductImg}
                          alt='...'
                          className='single-img'
                          width={50}
                          height={50}
                        />
                      </div>
                      <div className='product-badge'>
                        <div className='badge-text'>
                          <img
                            src={productBadge}
                            alt='...'
                            className='badge-img'
                          />
                          <div className='badge-des'>Margin -45.9</div>
                        </div>
                      </div>
                      <div className='product-detail'>
                        <h5>Fresh Malabar Parota</h5>
                        <p>Qty-2Kg (10 Pockets)</p>
                        <p className='text-dark'> &#x20B9; 199</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className='col productsgroup-all mb-3'>
                  <div className='sinngleproducts'>
                    <div
                      style={{
                        backgroundColor: '#E3F6D1',
                        border: 'solid #E3F6D1',
                      }}
                      className='row p-2'
                    >
                      <div className='col-lg-10 col-xs-12 col-sm-12'>
                        <p className='fw-normal'>Total Products</p>
                      </div>
                      <div className='col-lg-2 col-xs-12 col-sm-12'>
                        <p>
                          11 Items | <span className='fw-bold'>₹4000</span>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        )}

        {activeContainer === 'container-3' && (
          <div className='container-3 mb-3 mt-3'>
            <Container>
              <Card>
                <Card.Header>My Orders / Tracking</Card.Header>
                <Card.Body>
                  {/* Order details */}
                  <h6>Order ID: OD45345345435</h6>
                  <Card>
                    <Card.Body className='row'>
                      <Col>
                        <strong>Estimated Delivery time:</strong>
                        <br />
                        29 Nov 2019
                      </Col>
                      <Col>
                        <strong>Shipping BY:</strong>
                        <br />
                        BLUEDART, | <i className='fa fa-phone'></i> +1598675986
                      </Col>
                      <Col>
                        <strong>Status:</strong>
                        <br />
                        Picked by the courier
                      </Col>
                      <Col>
                        <strong>Tracking #:</strong>
                        <br />
                        BD045903594059
                      </Col>
                    </Card.Body>
                  </Card>

                  {/* Tracking steps */}
                  <div className='track'>
                    <div className='step active'>
                      <span className='icon'>
                        <i className='fa fa-check'></i>
                      </span>
                      <span className='text'>Order confirmed</span>
                    </div>
                    <div className='step active'>
                      <span className='icon'>
                        <i className='fa fa-user'></i>
                      </span>
                      <span className='text'> Picked by courier</span>
                    </div>
                    <div className='step'>
                      <span className='icon'>
                        <i className='fa fa-truck'></i>
                      </span>
                      <span className='text'> On the way </span>
                    </div>
                    <div className='step'>
                      <span className='icon'>
                        <i className='fa fa-box'></i>
                      </span>
                      <span className='text'>Ready for pickup</span>
                    </div>
                  </div>

                  <hr />

                  {/* Ordered items */}
                  <Row className='mt-5'>
                    <Col md={4}>
                      <figure className='itemside mb-3'>
                        <div className='aside'>
                          <img
                            src='https://i.imgur.com/iDwDQ4o.png'
                            className='img-sm border'
                            alt='Dell Laptop'
                          />
                        </div>
                        <figcaption className='info align-self-center'>
                          <p className='title'>
                            Dell Laptop with 500GB HDD <br /> 8GB RAM
                          </p>
                          <span className='text-muted'>$950 </span>
                        </figcaption>
                      </figure>
                    </Col>
                    <Col md={4}>
                      <figure className='itemside mb-3'>
                        <div className='aside'>
                          <img
                            src='https://i.imgur.com/tVBy5Q0.png'
                            className='img-sm border'
                            alt='HP Laptop'
                          />
                        </div>
                        <figcaption className='info align-self-center'>
                          <p className='title'>
                            HP Laptop with 500GB HDD <br /> 8GB RAM
                          </p>
                          <span className='text-muted'>$850 </span>
                        </figcaption>
                      </figure>
                    </Col>
                    <Col md={4}>
                      <figure className='itemside mb-3'>
                        <div className='aside'>
                          <img
                            src='https://i.imgur.com/Bd56jKH.png'
                            className='img-sm border'
                            alt='ACER Laptop'
                          />
                        </div>
                        <figcaption className='info align-self-center'>
                          <p className='title'>
                            ACER Laptop with 500GB HDD <br /> 8GB RAM
                          </p>
                          <span className='text-muted'>$650 </span>
                        </figcaption>
                      </figure>
                    </Col>
                  </Row>

                  <hr />

                  {/* Back to orders button */}
                  <Button variant='warning' data-abc='true'>
                    <i className='fa fa-chevron-left'></i> Back to orders
                  </Button>
                </Card.Body>
              </Card>
            </Container>
          </div>
        )}
      </div>
      <Footer />
    </div>
  )
}

export default Order
